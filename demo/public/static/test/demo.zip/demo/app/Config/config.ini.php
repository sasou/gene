<?php
$config = new \gene\config();
$config->clear();
$config->set("dsfsdfsdd",array('_url'=>array('sd'=>'sdfsdsdfd  f222','sds'=>'sdfsf678'),'port'=>3307));
$config->set("dsfsdfsd.portd","asasdasasd");