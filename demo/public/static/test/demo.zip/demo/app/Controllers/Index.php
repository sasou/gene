<?php
namespace Controllers;
class Index extends \Gene\Controller
{
	function run()
	{
		echo ' index run ';
		$this->test = ' hello ';
		$this->arr = array("third");
		$this->display("index/run","common");
	}
    
	function test()
	{
		echo 'test';
	}  
}
