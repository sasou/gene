<?php
namespace Models;

class User
{
	function test()
	{
		echo ' app test ';
	}
}