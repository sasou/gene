<?php echo ' head run ';?>
<?php require $this->contains();?>
<?php echo ' foot run ';?>