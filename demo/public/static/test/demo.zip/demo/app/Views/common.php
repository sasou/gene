<?php echo ' head run ';?>
<?php $this::contains()?>
<?php echo ' foot run ';?>