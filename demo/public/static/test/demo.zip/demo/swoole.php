<?php
header("Content-type: text/html; charset=UTF-8");
define('APP_ROOT', __dir__ . '/app');
echo APP_ROOT;
$http = new swoole_http_server("127.0.0.1", 9501, SWOOLE_PROCESS);

//配置
$http->set([
    'worker_num' => 1, 
    'max_request' => 10000,
    'dispatch_mode'=> 2,
]);

$http->on("start", function ($server) {
    echo "Swoole http server is started";
});

$http->on("request", function ($request, $response) {
    $type = $request->server['request_method'] ?? "get";
    $url = $request->server['request_uri'] ?? "/";
    \Gene\Request::init($request->get, $request->post, $request->cookie, $request->server, null, $request->files);
    \Gene\Di::set("response", $response);
    
    ob_start();
    $app = \Gene\Application::getInstance();
    $app
    ->autoload(APP_ROOT)
    ->load("router.ini.php")
    ->load("config.ini.php")
    ->run($type, $url);
    
    $out = ob_get_contents();
    ob_end_clean();
    $out && $response->end($out);
});

$http->start();